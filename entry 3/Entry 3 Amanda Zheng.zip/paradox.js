<!DOCTYPE html>
<html>
  <head>
   <style>
@import url('https://fonts.cdnfonts.com/css/chopin-script');
</style>
<style>
 h1 {
     color: #ff7fa7;
     animation: floatUpDown 3s ease infinite;
 }

 @keyframes floatUpDown {
     0%, 100% {
         transform: translateY(30);
     }
     50% {
         transform: translateY(-30px);
     }
 }
   <style>
   <style>
     h1{color:#ff7fa7}
     h2{color:rgb(255, 127, 167)}
     p{color: #ff7fa7;}

     p:hover {
color: #ffffff; 
}

h2:hover {
color: #ffffff; 
}

h3:hover {
color: #ffffff; 
}


   </style>
   <style>
     body {
       background-image: url(https://cdn.discordapp.com/attachments/1130679716492365855/1153573873879613541/IMG_8423_2.jpg);
     background-size: cover;
     background-repeat: no-repeat;
     background-attachment: fixed;
     }
       </style>
<style>
 body {
     font-family: "helvetica", sans-serif;
     margin: 0;
     padding: 0;

 }

 p {
   color: #ff7fa7;
   margin: 40px; margin-left: 600px;
  
   
 }

 h1 {
   font-family: "Chopin Script", cursive; 
   color: #ff7fa7;
   font-size: 200px
   
   
 }

 h2 {
   color: #ff7fa7;
   margin: 40px;
   
 }

 h3 {
   color: #ff7fa7;
   margin: 40px; margin-left: 600px;
   
 }
 
</style>
<link href="/Users/amandazheng/Downloads/chopin-script/ChopinScript.ttf" rel="stylesheet">
    <title>PARADOX</title>
    <audio controls autoplay>
     <source src="https://cdn.discordapp.com/attachments/1130679716492365855/1153582892723740723/Dark_Ambience_Twinkle_Atmosphere_Sound_Effect.mp3" type="audio/mpeg">
 </audio>
  </head>
  <body>
   <textalign><center><h1>PARADOX</h1></center></textalign>
    <h2>THE FUTURE OF ARTIFICIAL INTELLIGENCE</h2>
    <h2>Can artificial intelligence and humans live harmoniously?</h2>
    <h3>Get ready to explore the future of design, where human ingenuity and AI's computational power combine to shape a world of unparalleled aesthetics and innovation.</h3>
    <p>For my Harmonic Collection project, I will explore the emerging topic of artificial intelligence and what this means for the future of humanity. Artistic direction is incredibly important to me so I would like to explore this concept through scenelike pages, similar to a cinematic film, or an interactive magazine transporting print into an unrecognizable digital realm. Within my theme of AI, I want to pair the human imagination with creative programmes such as mid journey to test the creative limits of artificial intelligence and serve as evidence of its incredible power 

     After coming across several news articles during the last few months, I’ve grown more interested in this cultural shift in not only the art world but in other areas like medicine, computer science, music, content creation and more. The current dialogue surrounding AI has become fertile ground to explore. I find this emerging topic unique from previous trends, one that will not rise and fall like the superfluous boom around other topics like NFT’s. Believing we are facing the next industrial revolution, I would love to play a part in this monumental shift and contribute to what creativity could look like in the future and how humans and artificial intelligence can live harmoniously. 
     
     Alternatively, I am incredibly fascinated by the idea of dichotomies, the balance of extremes. Not only does this perfectly illustrate the relationship between AI and humanity, it allows me to explore a diverse range of traits between both subjects. I am drawn to the rawness and unpredictability of human nature, planning to execute this visually through natural elements like eggs symbolizing birth, apples, the garden of eden, and viscous elements such as honey. These are the roots of our existence. On the other hand, Artificial intelligence is seemingly on the other end of the spectrum, one that has only lived a short existence so far. This makes the topic more ephemeral and hard to understand, a clear definition has yet to be set. 
     </p>
    <p>Created by Amanda Zheng</p>
  </body>
  <video id="scroll-video" autoplay muted loop>
    <source src="/Users/amandazheng/Documents/Adobe/Premiere Pro/23.0/y2mate.is - TIMELAPSE OF THE ENTIRE UNIVERSE-TBikbn5XJhg-1080pp-1695578801_1.mp4" type="video/mp4">
    <style>
      #video-container {
  display: flex;
  justify-content: center; 
  align-items: center; 
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;

}

#scroll-video {
  max-width: 100%;
  max-height: 100%;
}

<h1> 
    </style>
   <script>
    // Function to play or pause the video based on scrolling
    function adjustVideoPlayback() {
        var video = document.getElementById("scroll-video");
        var scrollPosition = window.scrollY;
        var containerTop = videoContainer.offsetTop;
        var containerHeight = videoContainer.offsetHeight;
        var windowHeight = window.innerHeight;

        // Adjust these values to control when the video should play and pause
        var playTriggerPosition = containerTop - windowHeight / 2;
        var pauseTriggerPosition = containerTop + containerHeight - windowHeight / 2;

        if (scrollPosition >= playTriggerPosition && scrollPosition <= pauseTriggerPosition) {
            // play the video when within the playTriggerPosition and pauseTriggerPosition
            video.play();
        } else {
            // Pause the video when outside of the playTriggerPosition and pauseTriggerPosition
            video.pause();
        }
    }

    var videoContainer = document.getElementById("video-container");

    // Attach the adjustVideoPlayback function to the scroll event
    document.addEventListener("scroll", adjustVideoPlayback);

    // Initialize video playback state
    adjustVideoPlayback();
</script>
  </video>
</html>